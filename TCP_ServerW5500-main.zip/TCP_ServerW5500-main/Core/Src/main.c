/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "socket.h"
#include "wizchip_conf.h"
#include "loopback.h"
#include "w5500.h"
#include "dhcp.h"
#include <stdio.h>
#include <string.h>
#include "stm32f4xx_hal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
uint8_t socket_buf[100];     						// Buffer to receive data
uint8_t rcvBuf[20],bufSize[]={2,2,2,2};
int32_t len;										//Len of data recived
wiz_NetInfo getInfo ={ .mac={0},  					//Mac address
	  		  	  	   .ip ={0}, 					// IP address
	    			   .sn ={0},					//Subnet mask
	    			   .gw ={0}};					//Gateway address
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//// SPI Functions  /////
void cs_sel(){
	 HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);
}
void cs_desel(){
	HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET);
}
uint8_t spi_rb(void){
	uint8_t rbuf;
	HAL_SPI_Receive(&hspi1,&rbuf,1,0xFFFFFFFF);
	return rbuf;
}
void spi_wb(uint8_t b){
	HAL_SPI_Transmit(&hspi1,&b,1,0xFFFFFFFF);
}


//#define MAX_DHCP_RETRY 5
//#define SOCK_DHCP 1
//
//uint8_t dhcp_buffer[1024];
//wiz_NetInfo netInfo;
//
//void my_ip_assign(void)
//{
//    getIPfromDHCP(netInfo.ip);
//    getGWfromDHCP(netInfo.gw);
//    getSNfromDHCP(netInfo.sn);
//    getDNSfromDHCP(netInfo.dns);
//    netInfo.dhcp = NETINFO_DHCP;
//    setSHAR(netInfo.mac);
//    wizchip_setnetinfo(&netInfo);
//
//    printf("DHCP assigned IP: %d.%d.%d.%d\r\n",
//        netInfo.ip[0], netInfo.ip[1], netInfo.ip[2], netInfo.ip[3]);
//}
//
//void my_ip_conflict(void)
//{
//    printf("IP conflict detected by DHCP!\r\n");
//    // Handle conflict - possibly halt or retry
//}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
   reg_wizchip_cs_cbfunc(cs_sel,cs_desel);
   reg_wizchip_spi_cbfunc(spi_rb,spi_wb);
   wizchip_init(bufSize,bufSize);
   wiz_NetInfo netInfo ={ .mac={0x00,0x08,0xdc,0xab,0xcd,0xef}, //Mac address
 		  	  	  	 	  .ip ={192,168,1,112}, 					// IP address
   						  .sn ={255,255,255,0},					//Subnet mask
   						  .gw ={192,168,1,1}};					//Gateway address
   HAL_Delay(500);
   wizchip_setnetinfo(&netInfo);
   HAL_Delay(500);
   wizchip_getnetinfo(&getInfo);

   //// this is for DHCP protocol ////


//   wiz_NetInfo netInfo = {
//       .mac = {0x00, 0x08, 0xdc, 0xab, 0xcd, 0xef},
//       .dhcp = NETINFO_DHCP // Set DHCP mode
//   };
//
//   setSHAR(netInfo.mac);  // Set MAC address
//   wizchip_setnetinfo(&netInfo);
//
//   // Initialize DHCP
//   DHCP_init(SOCK_DHCP, dhcp_buffer);
//   reg_dhcp_cbfunc(my_ip_assign, my_ip_assign, my_ip_conflict);
//
//   int dhcp_retry = 0;
//   while (1)
//   {
//       int8_t dhcp_status = DHCP_run();
//
//       if (dhcp_status == DHCP_IP_LEASED || dhcp_status == DHCP_IP_CHANGED)
//       {
//           printf("DHCP Success\r\n");
//           break;
//       }
//       else if (dhcp_status == DHCP_FAILED)
//       {
//           dhcp_retry++;
//           if (dhcp_retry > MAX_DHCP_RETRY)
//           {
////               printf("DHCP Failed - Falling back or resetting...\r\n");
////               // Optionally assign static IP or reset
////               while (1); // Halt or reset system
//           }
//       }
//
//       HAL_Delay(1000); // Wait a bit before retrying
//   }
   // 2. Open socket in TCP mode
//   int8_t sock_ret = socket(SOCK_TCPC, Sn_MR_TCP, SRC_PORT, 0);
//   if (sock_ret != SOCK_TCPC)
//   {
//       printf("Failed to open socket\r\n");
//       return;  // Or handle error
//   }
//
//   // 3. Connect to server
//   int conn_ret = connect(SOCK_TCPC, dest_ip, dest_port);
//   if (conn_ret != SOCK_OK)
//   {
//       printf("Failed to connect to server\r\n");
//       close(SOCK_TCPC);
//       return;  // Or handle error
//   }
//
//   // 4. Wait until connected
//   while (getSn_SR(SOCK_TCPC) != SOCK_ESTABLISHED)
//   {
//       if (getSn_SR(SOCK_TCPC) == SOCK_CLOSED)
//       {
//           printf("Socket closed unexpectedly\r\n");
//           return;
//       }
//       HAL_Delay(10); // Prevent busy-waiting
//   }
//
//   printf("TCP Client connected to server\r\n");

//// END here for DHCP protocol ////

	#define SOCK_TCPS 0         							     // Socket 0
	#define PORT_TCPS 502     								     // Listening port
	socket(SOCK_TCPS, Sn_MR_TCP, PORT_TCPS, 0); 				 // Open TCP socket
	listen(SOCK_TCPS);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  switch (getSn_SR(SOCK_TCPS)) {
	 	 	          case SOCK_ESTABLISHED:
	 	 	              if (getSn_IR(SOCK_TCPS) & Sn_IR_CON)
	 	 	              {
	 	 	                  setSn_IR(SOCK_TCPS, Sn_IR_CON); 			// Clear connection interrupt
	 	 	                  printf("Client connected\r\n");
	 	 	              }
	 	 	             uint8_t phy = getPHYCFGR();
	 					   if ((phy & 0x01) == 0) {
	 						   	   	   	   	   	   	   	   	   	   	   	// Link is down
	 						   close(SOCK_TCPS);
	 						   socket(SOCK_TCPS, Sn_MR_TCP, PORT_TCPS, 0);
	 						   listen(SOCK_TCPS);
	 					   }
	 	 	              // Check for received data
	 	 	              if ((len = getSn_RX_RSR(SOCK_TCPS)) > 0) {
	 	 	                  len = recv(SOCK_TCPS, socket_buf, len);  // Receive data
	 	 	                  socket_buf[len] = 0; // Null terminate
	 	 	                  printf("Received: %s\r\n", socket_buf);

//	 	 	                   Echo back the received data
	 	 	                  send(SOCK_TCPS, socket_buf, len);
	 	 	              }
	 	 	              break;

	 	 	          case SOCK_CLOSE_WAIT:
	 	 	              close(SOCK_TCPS);
	 	 	              socket(SOCK_TCPS, Sn_MR_TCP, PORT_TCPS, 0);
	 	 	              listen(SOCK_TCPS);
	 	 	              break;

	 	 	          case SOCK_CLOSED:
	 	 	              socket(SOCK_TCPS, Sn_MR_TCP, PORT_TCPS, 0);
	 	 	              listen(SOCK_TCPS);
	 	 	              break;

	 	 	          default:
	 	 	              break;
	 	 	      }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PC8 PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : CS_Pin */
  GPIO_InitStruct.Pin = CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
