Tiny AUX project to test Bootloader Zevero for AtMEGA 1284p
