This is Full working code for Wiegand_protocol using STM32 for RFID & etc.
