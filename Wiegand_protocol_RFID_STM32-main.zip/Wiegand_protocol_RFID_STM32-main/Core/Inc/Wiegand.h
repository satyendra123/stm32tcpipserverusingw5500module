/*
 * Wiegand.h
 *
 *  Created on: Nov 18, 2025
 *      Author: Houston
 */

#ifndef WIEGAND_H_
#define WIEGAND_H_

#include "main.h"
#include "stm32f4xx_hal.h"   // <-- Change this for your MCU series

typedef struct {
    volatile uint32_t cardTempHigh;   // Stores bits >32
    volatile uint32_t cardTempLow;    // Stores bits 0–31
    volatile uint32_t lastWiegand;    // Timestamp of last received pulse
    volatile uint8_t  bitCount;       // Number of bits received
    uint8_t  wiegandType;             // 4/8/24/26/32/34 bits
    uint32_t code;                    // Final decoded value
} WIEGAND_t;

extern WIEGAND_t Wiegand;

/* Initialization */
void WIEGAND_Init(void);

/* Called inside main loop, handles timeout + decoding */
void WIEGAND_Process(void);

/* Returns 1 when code is ready */
uint8_t WIEGAND_Available(void);

/* Returns decoded card number and clears it */
uint32_t WIEGAND_GetCode(void);

/* ISR handlers: call these from EXTI IRQ */
void WIEGAND_D0_Interrupt(void);
void WIEGAND_D1_Interrupt(void);


#endif /* WIEGAND_H_ */
