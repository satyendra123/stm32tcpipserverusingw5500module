/*
 * Wiegand.c
 *
 *  Created on: Nov 18, 2025
 *      Author: Houston
 */


#include "Wiegand.h"

WIEGAND_t Wiegand;

static uint32_t GetCardId(uint32_t *high, uint32_t *low, uint8_t bitLen);

void WIEGAND_Init(void)
{
    Wiegand.cardTempHigh = 0;
    Wiegand.cardTempLow = 0;
    Wiegand.bitCount = 0;
    Wiegand.lastWiegand = 0;
    Wiegand.code = 0;
    Wiegand.wiegandType = 0;
}

void WIEGAND_D0_Interrupt(void)
{
    Wiegand.bitCount++;

    if (Wiegand.bitCount > 31) {
        Wiegand.cardTempHigh |= ((Wiegand.cardTempLow & 0x80000000) >> 31);
        Wiegand.cardTempHigh <<= 1;
        Wiegand.cardTempLow <<= 1;
    } else {
        Wiegand.cardTempLow <<= 1;
    }

    Wiegand.lastWiegand = HAL_GetTick();
}

void WIEGAND_D1_Interrupt(void)
{
    Wiegand.bitCount++;

    if (Wiegand.bitCount > 31) {
        Wiegand.cardTempHigh |= ((Wiegand.cardTempLow & 0x80000000) >> 31);
        Wiegand.cardTempHigh <<= 1;
        Wiegand.cardTempLow |= 1;
        Wiegand.cardTempLow <<= 1;
    } else {
        Wiegand.cardTempLow |= 1;
        Wiegand.cardTempLow <<= 1;
    }

    Wiegand.lastWiegand = HAL_GetTick();
}

uint8_t WIEGAND_Available(void)
{
    return (Wiegand.code != 0);
}

uint32_t WIEGAND_GetCode(void)
{
    uint32_t tmp = Wiegand.code;
    Wiegand.code = 0;
    return tmp;
}

void WIEGAND_Process(void)
{
    uint32_t now = HAL_GetTick();

    if (now - Wiegand.lastWiegand > 25)  // same debounce as Arduino
    {
        if (Wiegand.bitCount == 4 || Wiegand.bitCount == 8 ||
            Wiegand.bitCount == 24 || Wiegand.bitCount == 26 ||
            Wiegand.bitCount == 32 || Wiegand.bitCount == 34)
        {
            Wiegand.cardTempLow >>= 1;
            if (Wiegand.bitCount > 32)
                Wiegand.cardTempHigh >>= 1;

            uint32_t id = GetCardId(&Wiegand.cardTempHigh,
                                    &Wiegand.cardTempLow,
                                    Wiegand.bitCount);

            Wiegand.code = id;
            Wiegand.wiegandType = Wiegand.bitCount;
        }

        Wiegand.bitCount = 0;
        Wiegand.cardTempLow = 0;
        Wiegand.cardTempHigh = 0;
    }
}

static uint32_t GetCardId(uint32_t *high, uint32_t *low, uint8_t bitLen)
{
    if (bitLen == 26)
        return (*low & 0x1FFFFFE) >> 1;

    if (bitLen == 24)
        return (*low & 0x7FFFFE) >> 1;

    if (bitLen == 34) {
        *high = *high & 0x03;
        *high <<= 30;
        *low >>= 1;
        return *high | *low;
    }

    if (bitLen == 32)
        return (*low & 0x7FFFFFFE) >> 1;

    return *low;
}
