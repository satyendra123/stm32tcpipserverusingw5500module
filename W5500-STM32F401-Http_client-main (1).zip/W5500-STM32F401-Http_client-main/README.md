This code is used for send data to webserver and tested code with server.
