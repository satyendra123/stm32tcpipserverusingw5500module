/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "socket.h"
#include "wizchip_conf.h"
#include "loopback.h"
#include "w5500.h"
#include <stdio.h>
#include <string.h>
//#include "MQTTClient.h"
#include "stm32f4xx_hal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
uint8_t socket_buf[100];     						// Buffer to receive data
uint8_t rcvBuf[20],bufSize[]={2,2,2,2};
int32_t len;										//Len of data recived
wiz_NetInfo getInfo ={ .mac={0},  					//Mac address
	  		  	  	   .ip ={0}, 					// IP address
	    			   .sn ={0},					//Subnet mask
	    			   .gw ={0}};					//Gateway address
#define SOCK_TCPC 0
#define SRC_PORT 5000
uint8_t dest_ip[4] = {192, 168, 1, 39};
uint16_t dest_port = 5000;
uint8_t tx_data[] = "Hello from W5500 TCP client!";
uint16_t tx_len = sizeof(tx_data);  // Include null terminator if needed

#define RX_BUF_SIZE 1024
//#define JSON_BUF_SIZE 512

uint8_t rx_buf[RX_BUF_SIZE];

int temp = 0;  // your counter
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void cs_sel(){
	 HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);
}
void cs_desel(){
	HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET);
}
uint8_t spi_rb(void){
	uint8_t rbuf;
	HAL_SPI_Receive(&hspi1,&rbuf,1,0xFFFFFFFF);
	return rbuf;
}
void spi_wb(uint8_t b){
	HAL_SPI_Transmit(&hspi1,&b,1,0xFFFFFFFF);
}


void send_post_request(void)
{
	while (1)
	{
	    // Step 1: Open Socket
	    int8_t sock = socket(SOCK_TCPC, Sn_MR_TCP, SRC_PORT, 0);
	    if (sock != SOCK_TCPC) {
	        printf("Socket open failed\n");
	        continue;
	    }

	    // Step 2: Connect to server
	    uint8_t dest_ip[4] = {192, 168, 1, 39};
	    uint16_t dest_port = 5000;
	    if (connect(SOCK_TCPC, dest_ip, dest_port) != SOCK_OK) {
	        printf("Socket connect failed\n");
	        close(SOCK_TCPC);
	        continue;
	    }

	    // Step 3: Build POST
//	    const char *json_body = "{\"name\":\"sensor1\",\"sub\":\"temperature\"}";
	    // 1. Create JSON body with temp value
	    char json_body[256];  // Buffer for your dynamic JSON
	    snprintf(json_body, sizeof(json_body),
	             "{\"name\":\"sensor1\",\"sub\":\"temperature\",\"Temp\":%d}", temp++);
	    int content_length = strlen(json_body);
	    char http_post[512];

	    snprintf(http_post, sizeof(http_post),
	        "POST /sensordata HTTP/1.1\r\n"
	        "Host: 192.168.1.21:5000\r\n"
	        "Content-Type: application/json\r\n"
	        "Content-Length: %d\r\n"
			"Connection: keep-alive\r\n"
	        "\r\n"
	        "%s",
	        content_length, json_body);

	    // Step 4: Send
	    int sent = send(SOCK_TCPC, (uint8_t*)http_post, strlen(http_post));
	    if (sent <= 0) {
	        printf("Send failed\n");
	    } else {
	        printf("POST sent\n");
	    }

//	     Step 5: Optionally receive response
	    uint8_t rx_buff[1024] = {0};
	    int32_t recv_len = recv(SOCK_TCPC, rx_buff, sizeof(rx_buff));
//	    if (recv_len > 0) {
//	        printf("Server said:\n%s\n", rx_buff);
//	    }

//char clean_json_body[JSON_BUF_SIZE];  // ✅ Renamed to avoid conflicts

// 1. Receive HTTP response
int32_t len = recv(SOCK_TCPC, rx_buf, RX_BUF_SIZE );  // Leave space for null terminator
//if (len > 0)
//{
//    rx_buf[len] = '\0';  // Null terminate to treat as string
//
//    // 2. Find start of JSON body
//    char *body_start = strstr((char *)rx_buf, "\r\n\r\n");
//    if (body_start != NULL)
//    {
//        body_start += 4;  // Skip past "\r\n\r\n"
//
//        // 3. Copy JSON body into clean array
//        strncpy(clean_json_body, body_start, JSON_BUF_SIZE - 1);
//        clean_json_body[JSON_BUF_SIZE - 1] = '\0';  // Ensure null-termination
//
//        // 4. Optional: clean trailing control characters
//        for (int i = 0; clean_json_body[i] != '\0'; i++) {
//            if ((clean_json_body[i] < 32) && clean_json_body[i] != '\n' && clean_json_body[i] != '\r') {
//                clean_json_body[i] = '\0';
//                break;
//            }
//        }
//
//        // ✅ Now print clean JSON body
//        printf("✅ JSON Body:\n%s\n", clean_json_body);
//    }
//    else
//    {
////    	 close(SOCK_TCPC);
//        printf("⚠️ No JSON body found in response.\n");
//    }
//}
//else
//{
//    printf("❌ recv() failed or returned no data.\n");
//}




//	     Step 6: Close socket
	    close(SOCK_TCPC);

	    // Step 7: Delay before next request
	    HAL_Delay(3000);  // 5 seconds
	}

//    const char *json_body = "{\"name\":\"sensor1\",\"sub\":\"temperature\"}";
//    int content_length = strlen(json_body);
//
//    char http_post[512];
//
//    snprintf(http_post, sizeof(http_post),
//        "POST /sensordata HTTP/1.1\r\n"
//        "Host: 192.168.1.21:5000\r\n"
//        "Content-Type: application/json\r\n"
//        "Content-Length: %d\r\n"
//        "\r\n"
//        "%s",
//        content_length, json_body);
//
//    // Send the request
//    send(SOCK_TCPC, (uint8_t*)http_post, strlen(http_post));
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  reg_wizchip_cs_cbfunc(cs_sel,cs_desel);
    reg_wizchip_spi_cbfunc(spi_rb,spi_wb);
    wizchip_init(bufSize,bufSize);
    wiz_NetInfo netInfo ={ .mac={0x00,0x08,0xdc,0xab,0xcd,0xef}, //Mac address
  		  	  	  	 	   .ip ={192,168,1,112}, 					// IP address
						   .sn ={255,255,255,0},					//Subnet mask
						   .gw ={192,168,1,1},
						   .dns = {8, 8, 8, 8}};					//Gateway address
    HAL_Delay(500);
    wizchip_setnetinfo(&netInfo);
    HAL_Delay(500);
    wizchip_getnetinfo(&getInfo);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    // Initialize TCP clint
    int8_t sock_ret = socket(SOCK_TCPC, Sn_MR_TCP, SRC_PORT, 0);
      if (sock_ret != SOCK_TCPC)
      {
          printf("Failed to open socket\r\n");
          return;  // Or handle error
      }

      // 3. Connect to server
      int conn_ret = connect(SOCK_TCPC, dest_ip, dest_port);
      if (conn_ret != SOCK_OK)
      {
          printf("Failed to connect to server\r\n");
          close(SOCK_TCPC);
          return;  // Or handle error
      }
      char http_post[512];
      const char *json_body = "{\"name\":\"sensor1\",\"sub\":\"temperature\"}";
      int content_length = strlen(json_body);


      snprintf(http_post, sizeof(http_post),
          "POST /sensordata HTTP/1.1\r\n"
          "Host: 192.168.1.39:5000\r\n"
          "Content-Type: application/json\r\n"
          "Content-Length: %d\r\n"
          "\r\n"
          "%s",
          content_length, json_body);
//      char http_post[] =
//          "POST /sensordata HTTP/1.1\r\n"
//          "Host: 192.168.1.39:5000\r\n"
//          "Content-Type: application/json\r\n"
//          "Content-Length: 41\r\n"
//          "\r\n"
//          "{\"name\":\"sensor1\",\"sub\":\"temperature\"}";
      char http_get[] =
          "GET /submit?value=123 HTTP/1.1\r\n"
          "Host: 192.168.1.39:5000\r\n"
          "Connection: close\r\n"
          "\r\n";

//      send(SOCK_TCPC, (uint8_t*)http_post, strlen(http_post));
  while (1)
  {
//	  int32_t sent_len = send(SOCK_TCPC, tx_data, tx_len);
//	  send(SOCK_TCPC, (uint8_t*)http_post, strlen(http_post));
	  send_post_request();
	 	  HAL_Delay(2000);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : CS_Pin */
  GPIO_InitStruct.Pin = CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
